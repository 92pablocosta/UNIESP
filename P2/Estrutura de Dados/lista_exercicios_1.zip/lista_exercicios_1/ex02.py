# Crie um programa que determine se um número inserido pelo usuário é par ou ímpar.

n = int(input('Digite um número: '))

if n % 2 == 0:
    print('O númeror é par')
else:
    print('O número é IMPAR')
